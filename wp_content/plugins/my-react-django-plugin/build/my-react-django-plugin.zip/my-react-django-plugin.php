<?php
/*
Plugin Name: My React Django Plugin
Description: A WordPress plugin to integrate a React frontend with a Django backend.
Version: 1.0
Author:Shanmuga Hospital
*/

function my_react_django_plugin_enqueue_scripts() {
    wp_enqueue_style('my-react-app-css', plugins_url('build/static/css/main.css', __FILE__));
    wp_enqueue_script('my-react-app-js', plugins_url('build/static/js/main.js', __FILE__), array(), null, true);
}
add_action('wp_enqueue_scripts', 'my_react_django_plugin_enqueue_scripts');

function my_react_django_plugin_shortcode() {
    return '<div id="root"></div>';
}
add_shortcode('my_react_django_app', 'my_react_django_plugin_shortcode');
?>
